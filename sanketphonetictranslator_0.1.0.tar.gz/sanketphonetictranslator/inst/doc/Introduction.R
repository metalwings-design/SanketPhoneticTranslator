## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(sanketphonetictranslator)

## ----eval = FALSE-------------------------------------------------------------
#  # Load
#  example_dataset <- as.data.frame("example_dataset")
#  
#  # Transliterate dataset from Hindi to English
#  translated_dataset <- transliterate_dataset(example_dataset, "hindi2english")
#  head(translated_dataset)

