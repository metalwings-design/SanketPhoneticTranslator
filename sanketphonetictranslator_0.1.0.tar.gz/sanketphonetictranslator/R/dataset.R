#' Dataset Description
#'
#' This is a dataset used for demonstration purposes in the sanketphonetictranslator package.
#'
#' @name dataset
#' @docType data
#' @usage data(dataset)
#' @format A data frame with specific format
#'
"dataset"
