#' @title  sanketphonetictranslator
#'
#' @description  This R package designed to facilitate phonetic transliteration between different languages. With support for both Hindi and English, this package provides a way to convert text between hindi and english dataset. Whether you're working with multilingual data or need to convert dataset for analysis or presentation purposes, SanketPhoneticTranslator offers a simple and efficient solution. Harness the power of phonetic transliteration in your R projects with this versatile package.
#'
#' @usage
#' transliterate_dataset(dataset, direction)
#'
#' @param dataset = insert name of dataset.
#'
#' @param direction = you can transliterate from hindi to english language and vice versa. use "hindi2english" and "english2hindi" accordingly.
#'
#' @examples
#'# assume that indidata as your dataset.
#'# To convert your dataset, use "hindi2english"in direction as parameter.
#' # transliterate_dataset(indidata, "hindi2english")
#' @importFrom stringi stri_trans_general
#' @import Rcpp
#' @import stringr
#' @author  Sanket Gharat
#' @export transliterate_dataset
#'

transliterate_dataset <- function(dataset, direction) {
  valid_directions <- c("hindi2english", "english2hindi")
  if (!(direction %in% valid_directions)) {
    stop("Invalid direction. Use 'hindi2english' or 'english2hindi'.")
  }


  transliterate_function <- switch(
    direction,
    "hindi2english" = function(text) {
      hindi_code_points <- stri_trans_general(text, "Devanagari-Latin")
      english_text <-
        stri_trans_general(hindi_code_points, "Latin-ASCII")
      return(english_text)
    },
    "english2hindi" = function(text) {
      english_code_points <- stri_trans_general(text, "Latin-Devanagari")
      hindi_text <-
        stri_trans_general(english_code_points, "Any-Devanagari")
      return(hindi_text)
    }
  )


  colnames_transliterated <-
    lapply(colnames(dataset), transliterate_function)


  dataset_transliterated <- lapply(dataset, function(col) {
    if (is.character(col)) {
      return(transliterate_function(col))
    } else {
      return(col)
    }
  })


  dataset_transliterated <- as.data.frame(dataset_transliterated)


  colnames(dataset_transliterated) <- colnames_transliterated

  return(dataset_transliterated)
}
